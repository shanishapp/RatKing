﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneManagerScript : MonoBehaviour
{
    public Transform parent;

    public float spawnGoodsSpeed;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(spawnGoods());
        //StartCoroutine(spawnBads());
    }

    IEnumerator spawnGoods()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawnGoodsSpeed);
            GameObject goodGO = Instantiate(Resources.Load("goodBall")) as GameObject;
            goodGO.transform.SetParent(parent);
            goodGO.transform.localPosition = Vector3.zero;
        }
    }
    IEnumerator spawnBads()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawnGoodsSpeed*3);
            GameObject goodGO = Instantiate(Resources.Load("badBall")) as GameObject;
            goodGO.transform.SetParent(parent);
            goodGO.transform.localPosition = Vector3.zero;
        }
    }
}
